/**
 * Created by anton on 07-Nov-16.
 */
let mapSort = require("./MapSort").mapSort;
result.mapSort = mapSort;