/**
 * Created by anton on 07-Nov-16.
 */
let Person = require('./person').Person;
result.Person = Person;