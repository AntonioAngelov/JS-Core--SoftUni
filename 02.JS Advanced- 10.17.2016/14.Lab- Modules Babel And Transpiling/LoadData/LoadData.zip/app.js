/**
 * Created by anton on 07-Nov-16.
 */
let functions = require('./functions');

result.sort = functions.sort;
result.filter = functions.filter;