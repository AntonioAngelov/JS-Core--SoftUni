/**
 * Created by anton on 07-Nov-16.
 */
let Branch = require('./Branch');
let Employee = require('./Employee');

result.Branch = Branch;
result.Employee = Employee;