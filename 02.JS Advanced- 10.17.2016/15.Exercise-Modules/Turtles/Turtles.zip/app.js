/**
 * Created by anton on 07-Nov-16.
 */
let Turtle = require('./Turtle');
let EvkodianTurtle = require('./EvkodianTurtle');
let NinjaTurtle = require('./NinjaTurtle');
let WaterTurtle = require('./WaterTurtle');
let GalapagosTurtle = require('./GalapagosTurtle');

result.Turtle = Turtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;
result.WaterTurtle = WaterTurtle;
result.GalapagosTurtle = GalapagosTurtle;

//let testWaterTurtle = new WaterTurtle("Michelangelo", 18, "male", "Sewer");
//let testGalapagusTurtle = new GalapagusTurtle("Raphael", 18, "male");
//let testEvkodianTurtle = new EvkodianTurtle("Donatello", 18, "male", 100);
//let testNinjaTurtle = new NinjaTurtle("Leonardo", 18, "male", "Blue", "Yamato");
//console.log(testWaterTurtle.toString());
//
//console.log(testGalapagusTurtle.toString());
//
//console.log(testEvkodianTurtle.toString());
//
//console.log(testNinjaTurtle.toString());

